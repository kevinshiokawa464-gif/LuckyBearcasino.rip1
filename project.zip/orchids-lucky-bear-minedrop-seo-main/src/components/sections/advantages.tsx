import React from "react";

const advantages = [
  {
    icon: "🎰",
    title: "Сертифицированные автоматы",
    text: "Свыше 1 000 слотов от лицензированных провайдеров: классика, новинки, прогрессивные джекпоты, live-игры. Генератор случайных чисел проверен независимыми аудиторами.",
  },
  {
    icon: "🎁",
    title: "Акции каждый день",
    text: "Приветственный пакет для новичков, еженедельный кэшбэк, фриспины за активность и уникальные промо-коды. Все условия прозрачны и публикуются заранее.",
  },
  {
    icon: "⚡",
    title: "Мгновенные выплаты",
    text: "Выводите на карты, кошельки и криптосчета. Запросы обрабатываются за минуты после верификации. Повторные выводы без дополнительных проверок.",
  },
  {
    icon: "📱",
    title: "Мобильная версия",
    text: "Адаптивный интерфейс работает на любом смартфоне прямо в браузере. Добавьте ярлык на рабочий стол для мгновенного старта без скачивания приложений.",
  },
  {
    icon: "👑",
    title: "VIP-программа",
    text: "Постоянных игроков ждут персональные менеджеры, повышенный кэшбэк, закрытые турниры и индивидуальные бонусы. Статус растёт вместе с активностью.",
  },
  {
    icon: "🛡️",
    title: "Безопасность 18+",
    text: "Все данные защищены SSL-шифрованием. Мы придерживаемся принципов ответственной игры: лимиты, самоисключение, защита несовершеннолетних.",
  },
];

export default function AdvantagesSection() {
  return (
    <section className="bg-background py-16">
      <div className="container mx-auto max-w-[1200px] px-4">
        <h2 className="mb-8 text-[28px] font-bold uppercase tracking-wide text-white">
          Ключевые преимущества Lucky Bear Casino
        </h2>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {advantages.map((a) => (
            <div
              key={a.title}
              className="rounded-2xl border border-white/5 bg-[rgba(15,23,42,0.6)] p-6 backdrop-blur-[8px]"
            >
              <h3 className="mb-3 flex items-start gap-2 text-[16px] font-semibold text-white">
                <span className="shrink-0">{a.icon}</span>
                {a.title}
              </h3>
              <p className="text-[14px] leading-[1.65] text-white/50">{a.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
